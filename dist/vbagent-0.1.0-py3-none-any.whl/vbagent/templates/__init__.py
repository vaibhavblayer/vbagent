"""Templates for generated documentation and context files."""

from .agentic_context import generate_context_file

__all__ = ["generate_context_file"]
