"""VBAgent - Physics question processing pipeline using OpenAI."""

__version__ = "0.1.0"
