"""Prompt modules for vbagent agents."""
